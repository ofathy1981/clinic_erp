1.Please copy zkcdc.inf to C:\WINDOWS\inf;
2.Please copy usbser.sys to C:\WINDOWS\system32\drivers.